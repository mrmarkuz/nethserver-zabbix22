# nethserver-zabbix22

nethserver-zabbix22 integrates the monitoring system into NethServer

## Installation

Browse to /zabbix and start monitoring!
