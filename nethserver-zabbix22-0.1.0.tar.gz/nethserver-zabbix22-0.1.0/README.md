# nethserver-zabbix22

nethserver-zabbix22 integrates the monitoring system into NethServer

## Installation

Install nethserver-zabbix22, browse to /zabbix and start monitoring.

## Documentation

https://community.nethserver.org/t/howto-install-zabbix-3-4/7841
