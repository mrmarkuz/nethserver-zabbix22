# nethserver-zabbix22

nethserver-zabbix22 integrates the oldstable monitoring system Zabbix 2.2 from epel into NethServer

## Installation

Install nethserver-zabbix22, browse to /zabbix and install zabbix via web UI.

The Zabbix db user password can be found in /var/lib/nethserver/zabbix.

## Documentation

https://community.nethserver.org/t/howto-install-zabbix-3-4/7841
